﻿using System;
using System.Collections.Generic;

namespace RecipeConsole_PROG6221_ST10089426
{
    //Created classes for recipe console
    class Recipe
    {
        //declaring variables
        private List<string> ingredients;
        private double[] _quantities;
        private string[] _units;                //Ingredients and Steps stored in an array list
        private List<string> steps;

        public Recipe()
        {
            ingredients = new List<string>();
            _quantities = new double[0];
            _units = new string[0];             //method for storing varibles into recipe
            steps = new List<string>();
        }


        //method for adding the ingredients
        public void AddIngredient(string name, double quantity, string unit)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException("Ingredient name cannot be null or empty.", nameof(name)); 
            }

            if (quantity < 0)               //add ingredient method
            {
                throw new ArgumentException("Quantity cannot be negative.", nameof(quantity));              //exception for handing null inputs
            }

            if (string.IsNullOrWhiteSpace(unit))
            {
                throw new ArgumentException("Unit cannot be null or empty.", nameof(unit));
            }

            ingredients.Add($"{quantity} {unit} {name}");
        }

        public void AddStep(string step)
        {
            if (string.IsNullOrWhiteSpace(step))        //mothod for adding a step
            {
                throw new ArgumentException("Step cannot be null or empty.", nameof(step));
            }

            steps.Add(step);
        }


        //display recipe method
        public void DisplayRecipe()
        {
            Console.WriteLine("Ingredients:");
            for (int i = 0; i < ingredients.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {ingredients[i]}");
            }

            Console.WriteLine("Steps:");
            for (int i = 0; i < steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
            }
        }

        public void ScaleRecipe(double factor)
        {
            for (int i = 0; i < ingredients.Count; i++)         //scale method
            {
                var (quantity, unit, name) = ParseIngredient(ingredients[i]);
                ingredients[i] = $"{quantity * factor} {unit} {name}";
            }
        }

        public void ResetQuantities()
        {                                                       //reset quantities method
            for (int i = 0; i < ingredients.Count; i++)
            {
                var (quantity, unit, name) = ParseIngredient(ingredients[i]);
                ingredients[i] = $"{quantity} {unit} {name}";
            }
        }

        //exit method
        public void ClearRecipe()
        {
            ingredients.Clear();        //clear method 
            steps.Clear();
        }

        private static (double, string, string) ParseIngredient(string ingredient)
        {
            var parts = ingredient.Split(' ', 3);
            var quantity = double.Parse(parts[0]);
            var unit = parts[1];                        //declare variables 
            var name = parts[2];
            return (quantity, unit, name);
        }
    }

    //main class
    internal class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe(); //create object called recipe


            //prompt user for inputs
            Console.WriteLine("Welcome to the Recipe Console!");
            Console.WriteLine("Please enter the number of ingredients:");
            int numIngredients = int.Parse(Console.ReadLine());

            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine("Enter the name of ingredient {0}:", i + 1);
                string name = Console.ReadLine();

                Console.WriteLine("Enter the quantity of ingredient {0}:", i + 1);      //for loop for user prompts
                var quantity = double.Parse(Console.ReadLine());

                Console.WriteLine("Enter the unit of measurement for ingredient {0}:", i + 1);
                string unit = Console.ReadLine();

                recipe.AddIngredient(name, quantity, unit);
            }

            Console.WriteLine("Please enter the number of steps:");
            int numSteps = int.Parse(Console.ReadLine());

            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine("Enter step {0}:", i + 1);
                string step = Console.ReadLine();

                recipe.AddStep(step);
            }
            Console.WriteLine("Recipe: ");
            Console.WriteLine(recipe);


            //while loop for user to choose what action to proceed with
            while (true)
            {
                Console.WriteLine("Enter a command (scale, reset, clear, exit):");
                string command = Console.ReadLine();

                if (command == "scale")
                {
                    Console.WriteLine("Enter a scaling factor (0.5, 2, 3):");
                    double factor = double.Parse(Console.ReadLine());

                    recipe.ScaleRecipe(factor);
                    Console.WriteLine(recipe);
                }
                else if (command == "reset")
                {
                    recipe.ResetQuantities();
                    Console.WriteLine(recipe);
                }
                else if (command == "clear")
                {
                    recipe.ClearRecipe();
                    Console.WriteLine("Recipe data cleared.");
                }
                else if (command == "exit")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid command. Please try again.");
                }
            }

            Console.WriteLine("Goodbye!"); //end of the program
        }
    }
}
